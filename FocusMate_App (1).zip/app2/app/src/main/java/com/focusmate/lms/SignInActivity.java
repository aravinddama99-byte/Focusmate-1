package com.focusmate.lms;

import android.accounts.AccountManager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

/** Sign in with a Google account. Uses Google Identity when a web client ID is configured, otherwise the device account picker. */
public class SignInActivity extends Activity {
    private TextView msg;
    private Button btn;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        float d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding((int) (32 * d), (int) (32 * d), (int) (32 * d), (int) (32 * d));
        root.setBackgroundColor(Color.parseColor("#09090A"));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        root.addView(logo, new LinearLayout.LayoutParams((int) (84 * d), (int) (84 * d)));

        root.addView(text("Welcome to FocusMate", 26, Color.WHITE, true, 24 * d));
        root.addView(text("Sign in with your Google account to save your progress and connect with friends.", 15, Color.parseColor("#A5A29C"), false, 10 * d));

        btn = new Button(this);
        btn.setAllCaps(false);
        btn.setText("G   Continue with Google");
        btn.setTextSize(16);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setTextColor(Color.parseColor("#13163B"));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(60 * d);
        btn.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, (int) (56 * d));
        lp.topMargin = (int) (36 * d);
        root.addView(btn, lp);
        btn.setOnClickListener(v -> signIn());

        msg = text("", 13, Color.parseColor("#FF8A95"), false, 14 * d);
        root.addView(msg);
        setContentView(root);
    }

    private TextView text(String s, int sp, int color, boolean bold, float topPad) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        t.setPadding(0, (int) topPad, 0, 0);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private void signIn() {
        msg.setText("");
        btn.setEnabled(false);
        if (AppConfig.GOOGLE_WEB_CLIENT_ID.isEmpty()) { pickDeviceAccount(); return; }
        try {
            CredentialManager cm = CredentialManager.create(this);
            GetGoogleIdOption opt = new GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(AppConfig.GOOGLE_WEB_CLIENT_ID)
                .build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            cm.getCredentialAsync(this, req, new CancellationSignal(), ContextCompat.getMainExecutor(this),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override public void onResult(GetCredentialResponse r) {
                        Credential c = r.getCredential();
                        if (c instanceof CustomCredential
                            && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
                            try {
                                GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(((CustomCredential) c).getData());
                                done(g.getDisplayName(), g.getId(),
                                    g.getProfilePictureUri() == null ? "" : g.getProfilePictureUri().toString(), g.getIdToken());
                            } catch (Exception e) { fail("Could not read your Google account."); }
                        } else fail("Unexpected sign-in result.");
                    }
                    @Override public void onError(GetCredentialException e) { fail("Sign-in was cancelled or failed. Please try again."); }
                });
        } catch (Exception e) { fail("Google sign-in is not available on this device."); }
    }

    // ---- fallback: the device's own Google account chooser (no Cloud Console setup needed)
    private void pickDeviceAccount() {
        try {
            Intent i = AccountManager.newChooseAccountIntent(null, null, new String[]{"com.google"}, null, null, null, null);
            startActivityForResult(i, 77);
        } catch (Exception e) { fail("No Google account found on this device."); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != 77) return;
        if (res == RESULT_OK && data != null) {
            String email = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            if (email != null && !email.isEmpty()) {
                String n = email.contains("@") ? email.substring(0, email.indexOf('@')) : email;
                done(n, email, "", "");
                return;
            }
        }
        fail("No account selected.");
    }

    private void done(String name, String email, String photo, String idToken) {
        new UserStore(this).save(name, email, photo, idToken);
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    private void fail(String m) {
        runOnUiThread(() -> { msg.setText(m); btn.setEnabled(true); });
    }
}
