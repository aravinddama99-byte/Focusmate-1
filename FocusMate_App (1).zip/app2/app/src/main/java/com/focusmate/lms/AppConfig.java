package com.focusmate.lms;

/** Edit these two values after you set up Google sign-in and deploy the friends server (see SETUP.md). */
public final class AppConfig {
    private AppConfig() {}

    /** Your friends/XP server, e.g. "https://focusmate-api.onrender.com". Leave empty to run without friends. */
    public static final String BACKEND_URL = "";

    /** "Web application" OAuth client ID from Google Cloud Console. Leave empty to use the simple account picker. */
    public static final String GOOGLE_WEB_CLIENT_ID = "";

    /** XP lost each time you open a blocked app anyway. Must match the number in the web app. */
    public static final int PENALTY_XP = 25;
}
