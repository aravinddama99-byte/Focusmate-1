package com.focusmate.lms;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** The signed-in Google user (name, email, token). */
public class UserStore {
    private final SharedPreferences sp;
    public UserStore(Context c) { sp = c.getSharedPreferences("user", Context.MODE_PRIVATE); }

    public boolean signedIn() { return !sp.getString("email", "").isEmpty(); }
    public void save(String name, String email, String photo, String idToken) {
        sp.edit().putString("name", name == null ? "" : name).putString("email", email == null ? "" : email)
            .putString("photo", photo == null ? "" : photo).putString("idToken", idToken == null ? "" : idToken).apply();
    }
    public void clear() { sp.edit().clear().apply(); }

    public String json() {
        try {
            JSONObject o = new JSONObject();
            o.put("signedIn", signedIn());
            o.put("name", sp.getString("name", ""));
            o.put("email", sp.getString("email", ""));
            o.put("photo", sp.getString("photo", ""));
            o.put("idToken", sp.getString("idToken", ""));
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }
}
