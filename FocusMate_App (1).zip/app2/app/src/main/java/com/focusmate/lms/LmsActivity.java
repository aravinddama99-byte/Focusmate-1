package com.focusmate.lms;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.json.JSONObject;

/** CU LMS inside the app (no external browser). "Import" reads the visible page and sends it to the LMS importer. */
public class LmsActivity extends Activity {
    public static final String EXTRA_URL = "url", EXTRA_TITLE = "title";
    public static volatile String pendingText = null;
    private WebView web;
    private ProgressBar bar;
    private TextView title;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final float d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#09090A"));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding((int) (8 * d), (int) (8 * d), (int) (12 * d), (int) (8 * d));
        Button close = flat("✕");
        close.setOnClickListener(v -> finish());
        top.addView(close, new LinearLayout.LayoutParams((int) (44 * d), (int) (44 * d)));
        title = new TextView(this);
        title.setTextColor(Color.WHITE); title.setTextSize(15); title.setTypeface(null, Typeface.BOLD);
        title.setSingleLine(true);
        String t = getIntent().getStringExtra(EXTRA_TITLE);
        title.setText(t == null || t.isEmpty() ? "CU LMS" : t);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button imp = new Button(this);
        imp.setAllCaps(false); imp.setText("Import to FocusMate"); imp.setTextSize(13);
        imp.setTextColor(Color.WHITE); imp.setTypeface(null, Typeface.BOLD);
        GradientDrawable g = new GradientDrawable(); g.setColor(Color.parseColor("#FF5B2E")); g.setCornerRadius(40 * d);
        imp.setBackground(g);
        imp.setPadding((int) (14 * d), 0, (int) (14 * d), 0);
        imp.setOnClickListener(v -> doImport());
        top.addView(imp, new LinearLayout.LayoutParams(-2, (int) (38 * d)));
        root.addView(top);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        root.addView(bar, new LinearLayout.LayoutParams(-1, (int) (3 * d)));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                return !("http".equals(sc) || "https".equals(sc)); // everything web stays in this view
            }
            @Override public void onPageFinished(WebView v, String url) { bar.setProgress(100); bar.setVisibility(View.GONE); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { bar.setVisibility(p < 100 ? View.VISIBLE : View.GONE); bar.setProgress(p); }
            @Override public void onReceivedTitle(WebView v, String t) { if (getIntent().getStringExtra(EXTRA_TITLE) == null) title.setText(t); }
        });
        String url = getIntent().getStringExtra(EXTRA_URL);
        web.loadUrl(url == null || url.isEmpty() ? "https://lms.cuchd.in" : url);
    }

    private Button flat(String t) {
        Button b = new Button(this);
        b.setText(t); b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.TRANSPARENT); b.setTextSize(18);
        return b;
    }

    private void doImport() {
        web.evaluateJavascript("(function(){return document.body?document.body.innerText:''})()", val -> {
            String text = "";
            try { text = new JSONObject("{\"v\":" + val + "}").getString("v"); } catch (Exception ignored) {}
            if (text.trim().length() < 20) {
                android.widget.Toast.makeText(this, "Open your subjects or assignments page first, then tap Import.", android.widget.Toast.LENGTH_LONG).show();
                return;
            }
            pendingText = text;
            Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
            finish();
        });
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (web != null) { web.destroy(); } super.onDestroy(); }
}
