package com.focusmate.lms;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

/** Plays the FocusMate intro animation (assets/intro.html) full-screen, then opens the app. */
public class SplashActivity extends Activity {
    private boolean left = false;
    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#07060C"));
        getWindow().setNavigationBarColor(Color.parseColor("#07060C"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#07060C"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void done() { ui.post(SplashActivity.this::next); }
        }, "FMIntro");
        web.loadUrl("https://appassets.androidplatform.net/assets/intro.html");
        ui.postDelayed(this::next, 9000); // safety net
    }

    private void next() {
        if (left) return;
        left = true;
        Class<?> to = new UserStore(this).signedIn() ? MainActivity.class : SignInActivity.class;
        startActivity(new Intent(this, to));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override protected void onDestroy() { ui.removeCallbacksAndMessages(null); if (web != null) web.destroy(); super.onDestroy(); }
}
