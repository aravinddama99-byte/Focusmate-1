package com.focusmate.lms;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Watches the foreground app. During a focus session it covers blocked apps with a warning screen. */
public class BlockerService extends AccessibilityService {
    private ShieldStore store;
    private WindowManager wm;
    private LinearLayout overlay;
    private String overlayPkg;
    private TextView timeView;
    private final Handler h = new Handler(Looper.getMainLooper());

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (overlay == null) return;
            long left = store.endAt() - System.currentTimeMillis();
            if (left <= 0 || !store.active()) { hideOverlay(); return; }
            long s = left / 1000;
            timeView.setText(String.format("%02d:%02d left in your session", s / 60, s % 60));
            h.postDelayed(this, 1000);
        }
    };

    @Override public void onServiceConnected() {
        store = new ShieldStore(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getPackageName() == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (store == null) store = new ShieldStore(this);
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        String pkg = e.getPackageName().toString();

        if (overlay != null) {
            if (!pkg.equals(overlayPkg) && !pkg.equals("com.android.systemui")) hideOverlay();
            else return;
        }
        if (!store.active() || pkg.equals(getPackageName())) return;
        String name = store.blocked().get(pkg);
        if (name == null || store.isAllowed(pkg)) return;
        showOverlay(pkg, name);
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private TextView tv(String t, int sp, int color, boolean bold, int topDp) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(topDp), 0, 0);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    private Button btn(String t, int fill, int ink, int stroke) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(16); b.setTextColor(ink);
        b.setTypeface(null, Typeface.BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(30));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    private void showOverlay(final String pkg, final String name) {
        overlayPkg = pkg;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(28), dp(28), dp(28));
        root.setBackgroundColor(Color.parseColor("#F2070709"));

        root.addView(tv("⚠️", 48, Color.WHITE, false, 0));
        root.addView(tv("You opened " + name, 26, Color.WHITE, true, 12));
        root.addView(tv("It's blocked during your focus session.\nIf you continue you'll lose " + AppConfig.PENALTY_XP + " XP.",
            16, Color.parseColor("#FFB27A"), false, 10));
        timeView = tv("", 15, Color.parseColor("#7CF2B0"), true, 14);
        root.addView(timeView);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.topMargin = dp(26);
        root.addView(col, clp);

        Button stay = btn("Stay focused", Color.parseColor("#FF5B2E"), Color.WHITE, 0);
        stay.setOnClickListener(v -> goHome());
        Button end = btn("End focus session", Color.TRANSPARENT, Color.WHITE, Color.parseColor("#55FFFFFF"));
        end.setOnClickListener(v -> {
            store.queue("end", name);
            store.stop();
            hideOverlay();
        });
        Button open = btn("Open anyway  (−" + AppConfig.PENALTY_XP + " XP)", Color.TRANSPARENT, Color.parseColor("#FF6B78"), 0);
        open.setOnClickListener(v -> {
            store.queue("penalty", name);
            store.allow(pkg, System.currentTimeMillis() + 3 * 60_000L);
            hideOverlay();
        });
        col.addView(stay); col.addView(end); col.addView(open);

        root.setFocusableInTouchMode(true);
        root.setOnKeyListener((v, code, ev) -> {
            if (code == KeyEvent.KEYCODE_BACK) { if (ev.getAction() == KeyEvent.ACTION_UP) goHome(); return true; }
            return false;
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        try {
            wm.addView(root, lp);
            overlay = root;
            root.requestFocus();
            store.queue("blocked", name);
            h.post(tick);
        } catch (Exception ex) { overlay = null; performGlobalAction(GLOBAL_ACTION_HOME); }
    }

    private void goHome() { hideOverlay(); performGlobalAction(GLOBAL_ACTION_HOME); }

    private void hideOverlay() {
        h.removeCallbacks(tick);
        if (overlay != null) { try { wm.removeView(overlay); } catch (Exception ignored) {} }
        overlay = null; overlayPkg = null;
    }

    @Override public void onInterrupt() { hideOverlay(); }
    @Override public boolean onUnbind(Intent i) { hideOverlay(); return super.onUnbind(i); }
}
