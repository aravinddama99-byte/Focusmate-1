package com.focusmate.lms;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

/** Current focus-shield configuration (written by the web app) and a queue of events for it. */
public class ShieldStore {
    private final SharedPreferences sp;
    public ShieldStore(Context c) { sp = c.getSharedPreferences("shield", Context.MODE_PRIVATE); }

    /** json: {apps:[{name,pkgs:[]}], endAt, subject, paused} */
    public void start(String json) { sp.edit().putString("cfg", json).apply(); }
    public void stop() { sp.edit().remove("cfg").apply(); }

    public boolean active() {
        try {
            JSONObject o = new JSONObject(sp.getString("cfg", "{}"));
            return !o.optBoolean("paused", false) && o.optLong("endAt", 0) > System.currentTimeMillis();
        } catch (Exception e) { return false; }
    }
    public long endAt() {
        try { return new JSONObject(sp.getString("cfg", "{}")).optLong("endAt", 0); } catch (Exception e) { return 0; }
    }
    /** package -> app display name for every blocked app. */
    public Map<String, String> blocked() {
        Map<String, String> m = new HashMap<>();
        try {
            JSONArray a = new JSONObject(sp.getString("cfg", "{}")).optJSONArray("apps");
            if (a == null) return m;
            for (int i = 0; i < a.length(); i++) {
                JSONObject app = a.getJSONObject(i);
                JSONArray pk = app.optJSONArray("pkgs");
                if (pk == null) continue;
                for (int j = 0; j < pk.length(); j++) m.put(pk.getString(j), app.optString("name", pk.getString(j)));
            }
        } catch (Exception ignored) {}
        return m;
    }

    public void allow(String pkg, long until) { sp.edit().putLong("allow_" + pkg, until).apply(); }
    public boolean isAllowed(String pkg) { return sp.getLong("allow_" + pkg, 0) > System.currentTimeMillis(); }

    /** Events for the web app: {type:"blocked",app} or {type:"end"}. */
    public synchronized void queue(String type, String app) {
        try {
            JSONArray a = new JSONArray(sp.getString("queue", "[]"));
            JSONObject o = new JSONObject(); o.put("type", type); if (app != null) o.put("app", app);
            a.put(o);
            sp.edit().putString("queue", a.toString()).apply();
        } catch (Exception ignored) {}
    }
    public synchronized String takeQueue() {
        String q = sp.getString("queue", "[]");
        sp.edit().putString("queue", "[]").apply();
        return q;
    }
}
