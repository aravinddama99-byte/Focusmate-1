package com.focusmate.lms;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

/** Hosts the FocusMate UI and exposes the native features it needs as window.FocusMateNative. */
public class MainActivity extends Activity {
    private WebView web;
    private ShieldStore shield;
    private UserStore user;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private String appsCache = null;
    private boolean pinned = false;

    private final Runnable poll = new Runnable() {
        @Override public void run() { deliverEvents(); ui.postDelayed(this, 1500); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        shield = new ShieldStore(this);
        user = new UserStore(this);
        if (!user.signedIn()) { startActivity(new Intent(this, SignInActivity.class)); finish(); return; }

        getWindow().setStatusBarColor(Color.parseColor("#09090A"));
        getWindow().setNavigationBarColor(Color.parseColor("#09090A"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#09090A"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if ("appassets.androidplatform.net".equals(r.getUrl().getHost())) return false;
                openInApp(r.getUrl().toString(), "");
                return true;
            }
            @Override public void onPageFinished(WebView v, String url) { deliverEvents(); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                    .setPositiveButton("OK", (d, w) -> r.confirm()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                    .setPositiveButton("Yes", (d, w) -> r.confirm())
                    .setNegativeButton("No", (d, w) -> r.cancel()).show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "FocusMateNative");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        if (web == null) return;
        ui.post(poll);
        js("window.FocusMateBridge&&window.FocusMateBridge.onResume&&window.FocusMateBridge.onResume()");
        String t = LmsActivity.pendingText;
        if (t != null) {
            LmsActivity.pendingText = null;
            js("window.__fmLmsText=" + JSONObject.quote(t) + ";window.dispatchEvent(new CustomEvent('fm-lms-text',{detail:window.__fmLmsText}))");
        }
    }

    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(poll); }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); }

    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){try{return !!(window.FocusMateBridge&&window.FocusMateBridge.onBack&&window.FocusMateBridge.onBack())}catch(e){return false}})()",
            v -> { if (!"true".equals(v)) moveTaskToBack(true); });
    }

    @Override protected void onDestroy() { ui.removeCallbacks(poll); super.onDestroy(); }

    private void js(final String code) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); }); }

    private void deliverEvents() {
        String q = shield.takeQueue();
        if (q == null || q.equals("[]")) return;
        js("window.__fmNative&&window.__fmNative(" + q + ")");
    }

    private boolean serviceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String full = new ComponentName(this, BlockerService.class).flattenToString();
        String shortN = new ComponentName(this, BlockerService.class).flattenToShortString();
        for (String x : enabled.split(":")) if (x.equalsIgnoreCase(full) || x.equalsIgnoreCase(shortN)) return true;
        return false;
    }

    private boolean notifAllowed() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void openInApp(String url, String title) {
        Intent i = new Intent(this, LmsActivity.class).putExtra(LmsActivity.EXTRA_URL, url).putExtra(LmsActivity.EXTRA_TITLE, title);
        startActivity(i);
    }

    private static String iconB64(Drawable d) {
        int sz = 64;
        Bitmap bm = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, sz, sz);
        d.draw(c);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 85, bo);
        return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    public class Bridge {
        @JavascriptInterface public String getStatus() {
            try {
                JSONObject o = new JSONObject();
                o.put("accessibilityEnabled", serviceEnabled());
                o.put("notificationsAllowed", notifAllowed());
                o.put("canPin", true);
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
        @JavascriptInterface public void openAccessibilitySettings() {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }
        @JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> { if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5); });
        }
        @JavascriptInterface public void startShield(String json) { shield.start(json); }
        @JavascriptInterface public void stopShield() { shield.stop(); }

        @JavascriptInterface public synchronized String getInstalledApps() {
            if (appsCache != null) return appsCache;
            try {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                Set<String> seen = new HashSet<>();
                List<JSONObject> tmp = new ArrayList<>();
                for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                    JSONObject o = new JSONObject();
                    o.put("pkg", pkg);
                    o.put("name", String.valueOf(ri.loadLabel(pm)));
                    try { o.put("icon", iconB64(ri.loadIcon(pm))); } catch (Exception ignored) {}
                    tmp.add(o);
                }
                Collections.sort(tmp, (a, c) -> a.optString("name").compareToIgnoreCase(c.optString("name")));
                JSONArray arr = new JSONArray();
                for (JSONObject o : tmp) arr.put(o);
                appsCache = arr.toString();
            } catch (Exception e) { appsCache = "[]"; }
            return appsCache;
        }

        @JavascriptInterface public void openUrl(String url) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) {}
        }
        @JavascriptInterface public void openInApp(String url, String title) { runOnUiThread(() -> MainActivity.this.openInApp(url, title)); }

        @JavascriptInterface public void showNotification(String title, String body) {
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel("fm", "FocusMate", NotificationManager.IMPORTANCE_DEFAULT));
                android.app.Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(MainActivity.this, "fm") : new android.app.Notification.Builder(MainActivity.this);
                nb.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true);
                nm.notify((int) (System.currentTimeMillis() % 100000), nb.build());
            } catch (Exception ignored) {}
        }
        @JavascriptInterface public void vibrate(int ms) {
            try { ((Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(Math.max(10, ms)); } catch (Exception ignored) {}
        }
        @JavascriptInterface public void keepScreenOn(boolean on) {
            runOnUiThread(() -> { if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); });
        }
        @JavascriptInterface public void pinScreen(boolean on) {
            runOnUiThread(() -> { try { if (on && !pinned) { startLockTask(); pinned = true; } else if (!on && pinned) { stopLockTask(); pinned = false; } } catch (Exception ignored) {} });
        }
        @JavascriptInterface public void setImmersive(boolean on) {
            runOnUiThread(() -> getWindow().getDecorView().setSystemUiVisibility(on
                ? View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                : View.SYSTEM_UI_FLAG_VISIBLE));
        }

        // ---- additions for the app version
        @JavascriptInterface public String getUser() { return user.json(); }
        @JavascriptInterface public String getConfig() {
            try { return new JSONObject().put("backend", AppConfig.BACKEND_URL).put("penalty", AppConfig.PENALTY_XP).toString(); }
            catch (Exception e) { return "{}"; }
        }
        @JavascriptInterface public void signOut() {
            shield.stop(); user.clear();
            runOnUiThread(() -> { startActivity(new Intent(MainActivity.this, SignInActivity.class)); finish(); });
        }
        @JavascriptInterface public void share(String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Share"));
            });
        }
        @JavascriptInterface public void copy(String text) {
            runOnUiThread(() -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("FocusMate", text));
            });
        }

        /** Network call made natively so the page is not blocked by CORS / mixed content. Result -> window.__fmFetchDone(id,status,text). */
        @JavascriptInterface public void nativeFetch(final String id, final String url, final String method, final String headers, final String body) {
            new Thread(() -> {
                int status = 0; String text = "";
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(20000); c.setReadTimeout(90000);
                    c.setRequestMethod(method == null || method.isEmpty() ? "GET" : method);
                    JSONObject h = new JSONObject(headers == null || headers.isEmpty() ? "{}" : headers);
                    for (Iterator<String> it = h.keys(); it.hasNext();) { String k = it.next(); c.setRequestProperty(k, h.getString(k)); }
                    if (body != null && !body.isEmpty()) {
                        c.setDoOutput(true);
                        OutputStream os = c.getOutputStream(); os.write(body.getBytes("UTF-8")); os.close();
                    }
                    status = c.getResponseCode();
                    InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (is != null) {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192]; int n;
                        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                        text = bo.toString("UTF-8");
                    }
                } catch (Exception e) { status = 0; text = String.valueOf(e.getMessage()); }
                final int st = status; final String tx = text;
                js("window.__fmFetchDone(" + JSONObject.quote(id) + "," + st + "," + JSONObject.quote(tx) + ")");
            }).start();
        }
    }
}
